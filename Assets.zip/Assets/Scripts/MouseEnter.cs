using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MouseEnter : MonoBehaviour
{
    public PlayerControl pc;
    public GameObject box;
    
    
    private void OnMouseDown()
    {
        if (pc.sunduk <= 0)
        {
            print("err");
        }
        else
        {
            Instantiate(box,
                new Vector3(transform.position.x, transform.position.y + 3, transform.position.z),
                Quaternion.Euler(90, 0, 0));
            pc.sunduk--;
            
            Instantiate(gameObject,
                new Vector3(transform.position.x, transform.position.y / 2, transform.position.z),
                Quaternion.Euler(-90, 0, 0)).transform.localScale = new Vector3(transform.localScale.x, transform.localScale.y, transform.localScale.z * 2) ;
            
        }
    }

    private void OnMouseEnter()
    {
        GetComponent<Renderer>().material.color = Color.cyan;
    }
    
    private void OnMouseExit()
    {
        GetComponent<Renderer>().material.color = Color.white;
    }
}
