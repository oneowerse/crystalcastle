using System.Collections;
using Unity.Mathematics;
using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.UI;
using Random = UnityEngine.Random;
using UnityEngine.Rendering.Universal;

public class PlayerControl : MonoBehaviour
{
    private Rigidbody m_Rigidbody;
    public GameObject go;
    public Animator ai;
    private int stopForce = 1000, force = 2000;
    private float timer;
    public AudioSource aus;
    public AudioClip[] ac;
    private bool stop = false;
    public int sunduk = 5;
    public int Record = 0;
    public Text textBlockCount, textRecordCount;
    public GameObject Enemy;
    public ZoneGenerator zg;
    public MenuControls menu;
    public bool[] raycastes = new bool[10];
    
    
    // Start is called before the first frame update
    void Start()
    {
        m_Rigidbody = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {

        if (sunduk <= 0 && raycastes[0] == false
                        && raycastes[1] == false
                        && raycastes[2] == false
                        && raycastes[3] == false)
        {
            gameOver();
        }
        
        
        textBlockCount.text = "Block Count: " + sunduk;
        textRecordCount.text = "Record: " + Record;
        
        RaycastHit hit;
        // Does the ray intersect any objects excluding the player layer
        if (Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hit, 100))
        {
            Debug.DrawRay(transform.position, transform.TransformDirection(Vector3.forward),
                Color.blue);
            if (Input.GetKeyDown(KeyCode.A))
            {
                transform.position = new Vector3(hit.transform.position.x, 0.5f,
                    hit.transform.position.z - 1f);
                ai.Play("WalkPlayer");
                go.transform.rotation = Quaternion.Euler(0, 90, 0);
                aus.PlayOneShot(ac[0]);
            }if(Vector3.Distance(transform.position, hit.transform.position) < 2f) raycastes[0] = false;
            else  raycastes[0] = true;
            
        }
        else raycastes[0] = false;
        
        
        if (Physics.Raycast(transform.position, transform.TransformDirection(Vector3.right), out hit, 100))
        {
            Debug.DrawRay(transform.position, transform.TransformDirection(Vector3.right),
                Color.yellow);
            if (Input.GetKeyDown(KeyCode.W))
            {
                transform.position = new Vector3(hit.transform.position.x - 1f,0.5f,
                    hit.transform.position.z);
                ai.Play("WalkPlayer");
                go.transform.rotation = Quaternion.Euler(0, 180, 0);
                aus.PlayOneShot(ac[0]);
            }if(Vector3.Distance(transform.position, hit.transform.position) < 2f) raycastes[1] = false;
            else  raycastes[1] = true;
        }else raycastes[1] = false;

        if (Physics.Raycast(transform.position, transform.TransformDirection(Vector3.back), out hit, 100))
        {
            Debug.DrawRay(transform.position, transform.TransformDirection(Vector3.back),
                Color.red);
            if (Input.GetKeyDown(KeyCode.D))
            {
                transform.position = new Vector3(hit.transform.position.x, 0.5f,
                    hit.transform.position.z + 1f);
                ai.Play("WalkPlayer");
                go.transform.rotation = Quaternion.Euler(0, -90, 0);
                aus.PlayOneShot(ac[0]);
            }

            if (Vector3.Distance(transform.position, hit.transform.position) < 2f) raycastes[2] = false;
            else raycastes[2] = true;
        }

        if (Physics.Raycast(transform.position, transform.TransformDirection(Vector3.left), out hit, 100))
        {
            Debug.DrawRay(transform.position, transform.TransformDirection(Vector3.left),
                Color.green);
            
            if (Input.GetKeyDown(KeyCode.S))
            {
                transform.position = new Vector3(hit.transform.position.x + 1f, 0.5f,
                    hit.transform.position.z);
                ai.Play("WalkPlayer");
                go.transform.rotation = Quaternion.Euler(0, 0, 0);
                aus.PlayOneShot(ac[0]);
            }if(Vector3.Distance(transform.position, hit.transform.position) < 2f) raycastes[0] = false;
            else  raycastes[0] = true;
        }else raycastes[3] = false;

        timer -= Time.deltaTime;
    }


    private void OnTriggerEnter(Collider other)
    {
        if (other.name == "sunduk(Clone)")
        {
            if(Random.Range(0,4) != 0)
            {
                other.GetComponent<ParticleSystem>().Play();
                Destroy(other.gameObject, 1);
                sunduk += 3;
                Record += 3;
            }
            else
            {
                Destroy(Instantiate(Enemy, other.transform.position, quaternion.identity), 1);
                Destroy(other.gameObject);
            }
            aus.PlayOneShot(ac[2]);
        }
        
        if (other.name == "box(Clone)")
        {
            other.GetComponent<ParticleSystem>().Play();
            Destroy(other.gameObject, 1);
            sunduk ++;
            Record ++;
            other.gameObject.GetComponent<BoxCollider>().size = Vector3.zero;
            other.gameObject.GetComponent<BoxCollider>().isTrigger = true;
            aus.PlayOneShot(ac[2]);
        }
        
        if (other.name == "facet")
        {
            gameOver();
        }
        
        if (other.name == "CrystalDoor(Clone)")
        {
            zg.DestLevelNoTime();
            transform.position = new Vector3(transform.position.x + 2, transform.position.y, transform.position.z + 2);
            aus.PlayOneShot(ac[1]);
        }
    }

    public Volume v;
    
    public void gameOver()
    {
        
        aus.PlayOneShot(ac[3]);
        menu.MenuManagerTrue(2);

        StartCoroutine(wait());


    }

    public IEnumerator wait()
    {
        Bloom bloom;
        v.profile.TryGet<Bloom>(out bloom);
        for (int k = 1; k < 1000; k++)
        {
            bloom.intensity.value = k;
            yield return new WaitForSeconds(0.01f);
        }
    }
}
