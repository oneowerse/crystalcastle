using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MenuControls : MonoBehaviour
{
    public GameObject[] menues;

    public void Start()
    {
        menues[0].SetActive(true);
        menues[1].SetActive(false);
        menues[2].SetActive(false);
        PauseGame();
    }

    public void MenuManagerTrue(int menu)
    {
        menues[menu].SetActive(true);
    }
    public void MenuManagerFalse(int menu)
    {
        menues[menu].SetActive(false);
    }
    public void MenuRestaet()
    {
        SceneManager.LoadScene("Game");
    }
    public void PauseGame ()
    {
        Time.timeScale = 0;
    }
    public void ResumeGame ()
    {
        Time.timeScale = 1;
    }
}
