using System.Collections;
using UnityEngine;
using Random = UnityEngine.Random;

public class ZoneGenerator : MonoBehaviour
{
    [SerializeField] public GameObject[] gameAssets;
    [SerializeField] public Vector2 roomScaleMaxMin;
    private int _roomScale = 0;
    private Vector2 _lastPoint = new Vector2(0, 0);
    private bool isX;
    private Vector2 plus = new Vector2(0, 0);
    public GameObject insObj;
    public int i = 0;
    public PlayerControl pce;
    private int levelBlockCount;

    private GameObject[] lavel = new GameObject[1000];
    
    private void Start()
    {
        Generate();
        StartCoroutine(DestroyLavel());
    }

    public void Generate()
    {
        i = 0;
            plus = new Vector2(0, 0);
            int _roomScaleCopy = _roomScale;
            _roomScale += Random.Range(Mathf.RoundToInt(roomScaleMaxMin.x), Mathf.RoundToInt(roomScaleMaxMin.y + 1));
            Vector2 _lastPointCopy = _lastPoint;

            

                if (isX == true) plus.x = 2;
                else plus.y = 2;

                for (float x = _lastPointCopy.x - plus.x; x <= _roomScale; x++)
                {
                    for (float z = _lastPointCopy.y - plus.y; z <= _roomScale; z += 2)
                    {
                        if (Random.Range(4, 8) == 7)
                        {
                            lavel[i] = Instantiate(gameAssets[0], new Vector3(x, -1, z + 0.5f),
                                Quaternion.Euler(-90, 0, 0));
                            MouseEnter me = lavel[i].AddComponent<MouseEnter>();
                            me.pc = pce;
                            me.box = gameAssets[6];
                            lavel[i].transform.localScale = new Vector3(50, 100, 50);
                            i++;
                        }
                        else
                        {
                            lavel[i] = Instantiate(gameAssets[0], new Vector3(x, -1, z), Quaternion.Euler(-90, 0, 0));
                            MouseEnter me1 = lavel[i].AddComponent<MouseEnter>();
                            me1.pc = pce;
                            me1.box = gameAssets[6];
                            i++;
                            
                            lavel[i] = Instantiate(gameAssets[0], new Vector3(x, -1, z + 1), Quaternion.Euler(-90, 0, 0));
                            MouseEnter me2 = lavel[i].AddComponent<MouseEnter>();
                            me2.pc = pce;
                            me2.box = gameAssets[6];
                            i++;
                        }
                    }
                }

                for (int j = 0; j < Random.Range(0, 2); j++)
                {
                    lavel[i] = Instantiate(gameAssets[3], new Vector3(Random.Range(_lastPointCopy.x + 2, _roomScale - 2),
                        -0.25f,
                        Random.Range(_lastPointCopy.x + 2, _roomScale - 2)), Quaternion.Euler(0, 90, 0));
                    i++;
                }

                for (int j = 0; j < Random.Range(3, 6); j++)
                {
                    lavel[i] = Instantiate(gameAssets[4], new Vector3(Random.Range(_lastPointCopy.x + 2, _roomScale - 2),
                        2,
                        Random.Range(_lastPointCopy.x + 2, _roomScale - 2)), Quaternion.Euler(0, 90, 0));
                    i++;

                }






                float locationDoor = Random.Range(_roomScaleCopy, _roomScale);


                print("-----" + locationDoor);

                for (float x = _lastPointCopy.x - plus.x; x <= _roomScale + 1; x++)
                {
                    if (locationDoor % 2 == 0)
                    {
                        print("x");
                        if (locationDoor == x)
                        {
                            lavel[i] = Instantiate(gameAssets[2], new Vector3(x + 0.5f, -0.7f, _roomScale + 1),
                                Quaternion.Euler(0, 0, 0));
                            i++;
                            _lastPoint = new Vector2(x, _roomScale);
                            isX = true;
                        }
                        else if (locationDoor == x - 1)
                        {
                            print("end");
                        }
                        else
                        {
                            if (Random.Range(4, 8) == 7)
                            {
                                lavel[i] = Instantiate(gameAssets[1], new Vector3(x, -0.5f, _roomScale + 1),
                                    Quaternion.Euler(0, -90, 0));
                                i++;
                            }
                            else
                            {
                                lavel[i] = Instantiate(gameAssets[5], new Vector3(x, -0.5f, _roomScale + 1),
                                    Quaternion.Euler(0, -90, 0));
                                i++;
                            }
                        }
                    }
                    else if (Random.Range(4, 8) == 7)
                    {
                        lavel[i] = Instantiate(gameAssets[1], new Vector3(x, -0.5f, _roomScale + 1), Quaternion.Euler(0, -90, 0));
                        i++;
                    }else
                    {
                        
                        lavel[i] = Instantiate(gameAssets[5], new Vector3(x, -0.5f, _roomScale + 1), Quaternion.Euler(0, -90, 0));
                        i++;
                    }
                }

                for (float z = _lastPointCopy.y - plus.y; z <= _roomScale + 1; z++)
                {
                    if (locationDoor % 2 != 0)
                    {
                        print("z");
                        if (locationDoor == z)
                        {
                            lavel[i] = Instantiate(gameAssets[2], new Vector3(_roomScale + 1, -0.7f, z + 0.5f),
                                Quaternion.Euler(0, 90, 0));
                            i++;
                            i++;
                            // _lastPoint = new Vector2(_roomScale + 2, z - 1);
                            _lastPoint = new Vector2(_roomScale, z);
                            isX = false;
                        }
                        else if (locationDoor == z - 1)
                        {
                            print("end");
                        }
                        else
                        {
                            if (Random.Range(4, 8) == 7)
                            {
                                lavel[i] = Instantiate(gameAssets[1], new Vector3(_roomScale + 1, -0.5f, z),
                                    Quaternion.Euler(0, 0, 0));
                                i++;
                            }
                            else{
                                lavel[i] = Instantiate(gameAssets[5], new Vector3(_roomScale + 1, -0.5f, z),
                                    Quaternion.Euler(0, 0, 0));
                                i++;
                            }
                        }
                    }
                    else if (Random.Range(6, 8) == 7)
                    {
                        lavel[i] = Instantiate(gameAssets[1], new Vector3(_roomScale + 1, -0.5f, z),
                            Quaternion.Euler(0, 0, 0));
                        i++;
                    }
                    else {
                        lavel[i] = Instantiate(gameAssets[5], new Vector3(_roomScale + 1, -0.5f, z),
                            Quaternion.Euler(0, 0, 0));
                        i++;
                    }

                }

                levelBlockCount = i;


    }

    public MenuControls menu;
    public IEnumerator DestroyLavel()
    {
        for (int r = 0; r < i; r++)
        {
            if (lavel[r].name == "CrystalDoor(Clone)")
            {
                pce.gameOver();
            }

            for (byte j = 50; j > 0; j--)
            {
                yield return new WaitForSeconds(0.001f);
                lavel[r].transform.localScale = new Vector3(j, j, j);
            }
            lavel[r].SetActive(false);
        }
    }

    public void DestLevelNoTime()
    {
        for (int r = 0; r < levelBlockCount; r++)
        {
            Destroy(lavel[r]);
        }
        
        Generate();
        StartCoroutine(DestroyLavel());
        
    }

}
